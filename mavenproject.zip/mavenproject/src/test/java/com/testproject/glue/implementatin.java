package com.testproject.glue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.en.Given;

public class implementatin {
	
	@Given("^I want to write a step with precondition$")
	public void i_want_to_write_a_step_with_precondition() throws Exception {
		// Write code here that turns the phrase above into concrete actions
		WebDriver driver;

		// Setting webdriver.gecko.driver property
		//System.setProperty("webdriver.gecko.driver", pathToGeckoDriver + "\\geckodriver.exe");

		// Instantiating driver object and launching browser
		//driver = new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();

		// Using get() method to open a webpage
		driver.get("http://artoftesting.com");

		// Closing the browser
		driver.quit();
		//throw new PendingException();
	}

}
