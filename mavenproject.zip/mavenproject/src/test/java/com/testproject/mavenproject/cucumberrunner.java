package com.testproject.mavenproject;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
 
@RunWith(Cucumber.class)
@CucumberOptions(
		 plugin = { "pretty", "html:target/cucumber-reports" },
		    features = {"src/test/resource/test/"},
		    glue = {"com.testproject.glue"},
		    monochrome = true,
		    tags = {"@tort"}	    
		)

public class cucumberrunner {
	
//	@BeforeClass
//	public static void writeExtentReport() {
//		ExtentCucumberFormatter.initiateExtentCucumberFormatter();
//	}

}
